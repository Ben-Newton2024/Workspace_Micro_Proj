package doubloon;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.Security;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class clientCarl extends JPanel implements ActionListener
{
	private Socket client;
	private JButton send = new JButton("SEND 100 DOUBLOONS TO JIMMY");
	private JTextField inputmoneybox = new JTextField();
	
	public Wallet carlwallet;
	
	public clientCarl() {
		
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider()); //Setup Bouncey castle as a Security Provider

		carlwallet = new Wallet();
		
		
		send.addActionListener(this);
		inputmoneybox.addActionListener(this);
		
		this.setVisible(true);
		BorderLayout border = new BorderLayout();
		this.setLayout(border);
		this.add(send, border.NORTH);
		this.add(inputmoneybox, border.EAST);		
		
		
		try
		{
			client = new Socket("localhost", 8090 );
			// Read from this object.
	        ObjectInputStream in = new ObjectInputStream( client.getInputStream() );

	        Date date = ( Date ) in.readObject();

	        System.out.println("(Client) Current time is:          " + new Date() );
	        System.out.println("(Client) Object read from server : " + date );

		} catch (UnknownHostException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);

	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		// TODO Auto-generated method stub
		if(e.getSource() == send) {
	        try
			{
	            ObjectOutputStream out = new ObjectOutputStream(client.getOutputStream());
				out.writeObject("SEND"+ "#" + (carlwallet.publicKey) +"=" + "100f");
				
			} catch (IOException e1)
			{
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}
	}
	
	
	
}
