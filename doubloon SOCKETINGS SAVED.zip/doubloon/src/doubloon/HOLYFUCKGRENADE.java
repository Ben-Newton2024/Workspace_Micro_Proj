package doubloon;

import javax.swing.JFrame;

public class HOLYFUCKGRENADE
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		clientCarl carl = new clientCarl();
		
		
		JFrame Window = new JFrame();
		
		Window.setDefaultCloseOperation(Window.EXIT_ON_CLOSE);
		
		Window.setContentPane(carl);
		Window.setSize(640,800);
		Window.setVisible(true);
		
		
	}

}
